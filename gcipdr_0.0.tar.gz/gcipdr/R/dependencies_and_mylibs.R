## This file contains miscellaneous functions and info on dependencies.
## Copyright (C) 2018 Federico Bonofiglio

## This file is part of gcipdr.

    ## gcipdr is free software: you can redistribute it and/or modify
    ## it under the terms of the GNU General Public License as published by
    ## the Free Software Foundation, either version 3 of the License, or
    ## (at your option) any later version.

    ## gcipdr is distributed in the hope that it will be useful,
    ## but WITHOUT ANY WARRANTY; without even the implied warranty of
    ## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    ## GNU General Public License for more details.

    ## You should have received a copy of the GNU General Public License
    ## along with gcipdr.  If not, see <https://www.gnu.org/licenses/>.



### libraries to be loaded

## url <- "https://cran.r-project.org/src/contrib/Archive/JohnsonDistribution/JohnsonDistribution_0.24.tar.gz"
## pkgFile <- "JohnsonDistribution_0.24.tar.gz"
## download.file(url = url, destfile = pkgFile)

## install.packages(pkgs=pkgFile, type="source", repos=NULL)

## unlink(pkgFile)


warning("To use this package you need the following dependencies: JohnsonDistribution, moments, doParallel, doRNG, Rcpp, RcppArmadillo, cubature, mvtnorm, ggplot2")

warning("suggested package: xtable")



## ..... plus some miscellaneous functions


is.binary <-
         function(x, tol = .Machine$double.eps^0.5){  # check if var is binary

             x <- na.omit(x)
             
all( abs(x - round(x)) < tol & x >= 0 & x <= 1  )

         }  

#
reldist <- function(mean, true, range){  # relative distance


    (mean-true)/range

   }

# function to check is a parameter is finite or available

is.inf <- function( vec ){

   vec == Inf | vec == -Inf

}

#
is.inf.OR.na <- function( vec  ){

 is.inf(vec) | is.na(vec)    

}



#



 ## is vector in continuous domain ??

 is.continuous <- function(x){

       if ( is.numeric(x) | is.integer(x)) 
      !is.binary(x)
           else{
              if ( is.character(x) ) 
                  FALSE
              else{
                  if ( is.factor(x) ) 
                      FALSE
                       
                  }
              }     
   }


# are vectors in continuous domain ?

   are.continuous <- function( ds ){

       if ( !is.null( dim(ds) ) ) 

           unlist( lapply( ds, function(x) is.continuous(x) ) )
    else

        is.continuous(ds)
       
       }





#### function to convert some data columns into multirow latex code to be used within xtable

# df = data.frame, cols = target columns, span = number of multirow span for each column ...

make.multirow <- function( df, cols, span = rep(NA, length = dim(df)[2]), em = rep(NA, length = dim(df)[2]),
                          rotate = rep(FALSE, length(cols))){


 newcols <- do.call("cbind",

                   lapply(1:length(cols), function(j){
     
  label <- as.character(df[[ cols[j] ]]) # convert value into character
     if (is.na(span[j]))  # define row span
     span.row <- rle(label)$lengths
      else
          span.row <- span[j]
  if (is.na(em[j]))
   col.width <- "4em"
                       else
       col.width <- em[j]
                       
  first <- !duplicated(label)   # set duplicates to void
       label[!first] <- ""

# define appearance of \multirow
       if( rotate[j] ) 
label[first] <-
   paste0("\\parbox[t]{2mm}{\\multirow{", span.row, "}{*}{\\rotatebox[origin=c]{90}{", label[first], "}}}")
    else
  label[first] <-
   paste0("\\multirow{", span.row, "}{",col.width,"}{", label[first], "}")

                       
   return( label )
     }
  
        )  )
    
  df[, cols] <- newcols
  return( df )
    

}
